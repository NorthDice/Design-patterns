#include <iostream>
#include <map>
#include <functional>

class EventHandler {
public:
    virtual void handleEvent() = 0;
};

class ConcreteEventHandler : public EventHandler {
public:
    void handleEvent() override {
        std::cout << "ConcreteEventHandler is handling the event." << std::endl;
    }
};

class Reactor {
public:
    void registerHandler(int eventType, EventHandler* handler) {
        handlers[eventType] = handler;
    }

    void removeHandler(int eventType) {
        handlers.erase(eventType);
    }

    void handleEvents() {
        for (auto& pair : handlers) {
            pair.second->handleEvent();
        }
    }

private:
    std::map<int, EventHandler*> handlers;
};

int main() {
    Reactor reactor;
    ConcreteEventHandler concreteHandler;

    reactor.registerHandler(1, &concreteHandler);

    reactor.handleEvents();

    return 0;
}
