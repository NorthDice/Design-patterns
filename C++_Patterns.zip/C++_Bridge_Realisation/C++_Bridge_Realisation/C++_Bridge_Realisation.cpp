#include <iostream>

class Implementor {
public:
    virtual void operationImpl() = 0;
};

class ConcreteImplementorA : public Implementor {
public:
    void operationImpl() override {
        std::cout << "Concrete Implementor A operation" << std::endl;
    }
};

class ConcreteImplementorB : public Implementor {
public:
    void operationImpl() override {
        std::cout << "Concrete Implementor B operation" << std::endl;
    }
};

class Abstraction {
protected:
    Implementor* implementor;

public:
    Abstraction(Implementor* impl) : implementor(impl) {}

    virtual void operation() = 0;
};

class RefinedAbstractionA : public Abstraction {
public:
    RefinedAbstractionA(Implementor* impl) : Abstraction(impl) {}

    void operation() override {
        std::cout << "Refined Abstraction A operation: ";
        implementor->operationImpl();
    }
};

class RefinedAbstractionB : public Abstraction {
public:
    RefinedAbstractionB(Implementor* impl) : Abstraction(impl) {}

    void operation() override {
        std::cout << "Refined Abstraction B operation: ";
        implementor->operationImpl();
    }
};

int main() {
    ConcreteImplementorA implA;
    ConcreteImplementorB implB;

    RefinedAbstractionA refinedA(&implA);
    RefinedAbstractionB refinedB(&implB);

    refinedA.operation();
    refinedB.operation();

    return 0;
}
