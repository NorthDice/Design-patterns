#include <iostream>

class AbstractObject {
public:
    virtual void doSomething() = 0;
    virtual bool isNull() const = 0;
    virtual ~AbstractObject() {}
};


class RealObject : public AbstractObject {
public:
    void doSomething() override {
        std::cout << "RealObject is doing something." << std::endl;
    }

    bool isNull() const override {
        return false;
    }
};


class NullObject : public AbstractObject {
public:
    void doSomething() override {
    }

    bool isNull() const override {
        return true;
    }
};

int main() {
    AbstractObject* obj1 = new RealObject();
    AbstractObject* obj2 = new NullObject();

    obj1->doSomething();
    obj2->doSomething();

    std::cout << "obj1 is Null: " << (obj1->isNull() ? "true" : "false") << std::endl;
    std::cout << "obj2 is Null: " << (obj2->isNull() ? "true" : "false") << std::endl;

    delete obj1;
    delete obj2;

    return 0;
}
