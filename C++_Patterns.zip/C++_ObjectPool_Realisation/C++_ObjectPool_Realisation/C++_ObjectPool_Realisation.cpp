#include <iostream>
#include <vector>
#include <memory>

class Object {
public:
    void process() {
        std::cout << "Processing an object." << std::endl;
    }
};

class ObjectPool {
public:
    ObjectPool(size_t size) {
        for (size_t i = 0; i < size; ++i) {
            objects.push_back(std::make_shared<Object>());
        }
    }

    std::shared_ptr<Object> acquireObject() {
        if (objects.empty()) {
            return nullptr;
        }
        auto obj = objects.back();
        objects.pop_back();
        return obj;
    }

    void releaseObject(std::shared_ptr<Object> obj) {
        objects.push_back(obj);
    }

private:
    std::vector<std::shared_ptr<Object>> objects;
};

int main() {
    ObjectPool pool(5);

    auto obj1 = pool.acquireObject();
    auto obj2 = pool.acquireObject();

    if (obj1 && obj2) {
        obj1->process();
        obj2->process();
    }

    pool.releaseObject(obj1);
    pool.releaseObject(obj2);

    auto obj3 = pool.acquireObject();
    if (obj3) {
        obj3->process();
    }

    return 0;
}
